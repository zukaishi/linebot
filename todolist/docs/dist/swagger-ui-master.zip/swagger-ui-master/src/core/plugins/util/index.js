import { shallowEqualKeys } from "core/utils"

export default function() {
  return {
    fn: { shallowEqualKeys }
  }
}
